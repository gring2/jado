
create table vote(
	userNum varchar2(10) not null,
	chatNum varchar2(20) not null,
	agreed char not null,
	constraint fk_userNum foreign key(userNum)
	references user(userNum)
);