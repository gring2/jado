package org.scit.app.vo;

import java.util.List;

public class GantchartWarpper {
	
	private List<Gantchart> list;

	public List<Gantchart> getList() {
		return list;
	}

	public void setList(List<Gantchart> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "GantchartWarpper [list=" + list + "]";
	}

	

	
}
