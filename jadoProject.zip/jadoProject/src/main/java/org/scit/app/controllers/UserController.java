package org.scit.app.controllers;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.scit.app.persistence.UserDAO;
import org.scit.app.vo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController {
	@Autowired
	SqlSession sqlSession;
	
	private static final Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="joinView", method=RequestMethod.GET)
	public String joinView() {
		return "joinView";
	}
	
	@RequestMapping(value="idCheck", method=RequestMethod.POST)
	public @ResponseBody String idCheck(String usrId) {
		UserDAO dao = sqlSession.getMapper(UserDAO.class);
		
		String message = null;
		User user = dao.selectOne(usrId);
		System.out.println(user);
		if(user != null) {
			message = "fail";
		} else {
			message = "success";
		}
		
		return message;
	}
	
	@RequestMapping(value="join", method=RequestMethod.POST)
	public String join(User user) {
		UserDAO dao = sqlSession.getMapper(UserDAO.class);
		logger.info(user);
		int result = dao.insert(user);
		if(result == 0) {
			logger.info("회원가입 실패함...");
		}

		return "index";
	}
	
	@RequestMapping(value="update", method=RequestMethod.POST)
	public String update(User user) {
		UserDAO dao = sqlSession.getMapper(UserDAO.class);
		
		int result = dao.update(user);
		System.out.println(result + "개의 수정 완료");
		
		return "index";
	}
	
	@RequestMapping(value="loginView", method=RequestMethod.GET)
	public String loginView() {
		return "loginView";
	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(User user, HttpSession session) {
		UserDAO dao = sqlSession.getMapper(UserDAO.class);
		User vo = dao.selectOne(user.getUserid());
		
		if(vo.getUserpassword().equals(user.getUserpassword()))
			session.setAttribute("loginName", vo.getUsername());
		
		return "index";
	}
	
	@RequestMapping(value="logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "index";
	}
}
