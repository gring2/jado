
/* Drop Tables */

DROP TABLE JADO_SCRAP CASCADE CONSTRAINTS;
DROP TABLE JADO_CHAT CASCADE CONSTRAINTS;
DROP TABLE JADO_GANTMEMBER CASCADE CONSTRAINTS;
DROP TABLE JADO_GANTCHART CASCADE CONSTRAINTS;
DROP TABLE JADO_MEMBER CASCADE CONSTRAINTS;
DROP TABLE JADO_MSG CASCADE CONSTRAINTS;
DROP TABLE JADO_STORAGE CASCADE CONSTRAINTS;
DROP TABLE JADO_THEME CASCADE CONSTRAINTS;
DROP TABLE JADO_PROJECT CASCADE CONSTRAINTS;
DROP TABLE JADO_USER CASCADE CONSTRAINTS;





/* Create Tables */

CREATE TABLE JADO_SCRAP
(
	title varchar2(50),
	content varchar2(4000),
	startDate date,
	USERNUM varchar2(10 char) NOT NULL
);


CREATE TABLE JADO_CHAT
(
	CHATNUM varchar2(20 char) NOT NULL,
	CONTENT varchar2(4000 char) NOT NULL,
	CHATTYPE varchar2(10 char),
	STARTDATE date,
	CHATDATE date DEFAULT sysdate  NOT NULL,
	MEMNUM varchar2(20 char) NOT NULL,
	THMNUM varchar2(10 char) NOT NULL,
	CONSTRAINT SYS_C007544 PRIMARY KEY (CHATNUM)
);


CREATE TABLE JADO_GANTCHART
(
	GANTNUM varchar2(13 char) NOT NULL,
	PRONUM varchar2(10 char) NOT NULL,
	TODO varchar2(100 char) NOT NULL,
	CONSTRAINT SYS_C007548 PRIMARY KEY (GANTNUM)
);


CREATE TABLE JADO_GANTMEMBER
(
	USERNUM varchar2(10 char) NOT NULL,
	GANTNUM varchar2(13 char) NOT NULL,
	STARTDATE date,
	ENDDATE date,
	DURATION number(3,0),
	GANTPERCENT number(3,0) DEFAULT 0

);


CREATE TABLE JADO_MEMBER
(
	MEMNUM varchar2(20 char) NOT NULL,
	USERNUM varchar2(10 char) NOT NULL,
	PRONUM varchar2(10 char) NOT NULL,
	AGREED char(1 char) DEFAULT '''N'' ' NOT NULL,
	CONSTRAINT SYS_C007555 PRIMARY KEY (MEMNUM)
);


CREATE TABLE JADO_MSG
(
	CONTENT varchar2(4000 char),
	STARTDATE date,
	SENDER varchar2(100 char) NOT NULL,
	RECEIVER varchar2(100 char) NOT NULL,
	ISINVATE varchar2(4 char)
);


CREATE TABLE JADO_PROJECT
(
	PRONUM varchar2(10 char) NOT NULL,
	TITLE varchar2(100 char) NOT NULL,
	STARTDATE date DEFAULT sysdate  NOT NULL,
	ENDDATE date,
	USERNUM varchar2(10 char) NOT NULL,
	CONSTRAINT SYS_C007560 PRIMARY KEY (PRONUM)
);


CREATE TABLE JADO_STORAGE
(
	FILENAME varchar2(200 char) NOT NULL,
	THMNUM varchar2(10 char) NOT NULL
);


CREATE TABLE JADO_THEME
(
	THMNUM varchar2(10 char) NOT NULL,
	PRONUM varchar2(10 char) NOT NULL,
	THEMENAME varchar2(50 char) NOT NULL,
	CONSTRAINT SYS_C007566 PRIMARY KEY (THMNUM)
);


CREATE TABLE JADO_USER
(
	USERNUM varchar2(10 char) NOT NULL,
	ID varchar2(100 char) NOT NULL UNIQUE,
	PASSWORD varchar2(100 char) NOT NULL,
	NAME varchar2(20 char) NOT NULL,
	GOOGLEID varchar2(20 char),
	CONSTRAINT SYS_C007571 PRIMARY KEY (USERNUM)
);



/* Create Foreign Keys */

ALTER TABLE JADO_GANTMEMBER
	ADD CONSTRAINT SYS_C007578 FOREIGN KEY (GANTNUM)
	REFERENCES JADO_GANTCHART (GANTNUM)
	ON DELETE CASCADE
;


ALTER TABLE JADO_CHAT
	ADD CONSTRAINT SYS_C007579 FOREIGN KEY (MEMNUM)
	REFERENCES JADO_MEMBER (MEMNUM)
;


ALTER TABLE JADO_GANTCHART
	ADD CONSTRAINT SYS_C007581 FOREIGN KEY (PRONUM)
	REFERENCES JADO_PROJECT (PRONUM)
;


ALTER TABLE JADO_MEMBER
	ADD CONSTRAINT SYS_C007582 FOREIGN KEY (PRONUM)
	REFERENCES JADO_PROJECT (PRONUM)
;


ALTER TABLE JADO_THEME
	ADD CONSTRAINT SYS_C007583 FOREIGN KEY (PRONUM)
	REFERENCES JADO_PROJECT (PRONUM)
;


ALTER TABLE JADO_CHAT
	ADD CONSTRAINT SYS_C007584 FOREIGN KEY (THMNUM)
	REFERENCES JADO_THEME (THMNUM)
;


ALTER TABLE JADO_STORAGE
	ADD FOREIGN KEY (THMNUM)
	REFERENCES JADO_THEME (THMNUM)
;


ALTER TABLE JADO_SCRAP
	ADD FOREIGN KEY (USERNUM)
	REFERENCES JADO_USER (USERNUM)
;


ALTER TABLE JADO_GANTMEMBER
	ADD CONSTRAINT SYS_C007585 FOREIGN KEY (USERNUM)
	REFERENCES JADO_USER (USERNUM)
;


ALTER TABLE JADO_MEMBER
	ADD CONSTRAINT SYS_C007586 FOREIGN KEY (USERNUM)
	REFERENCES JADO_USER (USERNUM)
;


ALTER TABLE JADO_PROJECT
	ADD CONSTRAINT SYS_C007587 FOREIGN KEY (USERNUM)
	REFERENCES JADO_USER (USERNUM)
;

alter table jado_msg add constraint fk_receiver_msg foreign key(receiver)
references jado_user(id);

alter table jado_msg add constraint fk_sender2_msg foreign key(sender)
references jado_user(id)

drop sequence seq_user;
drop sequence seq_pro;
drop sequence seq_thm;
drop sequence seq_cht;

CREATE SEQUENCE seq_user INCREMENT BY 1 START WITH 1 MAXVALUE 999999999;

CREATE SEQUENCE seq_pro INCREMENT BY 1 START WITH 1 MAXVALUE 999999999;

CREATE SEQUENCE seq_thm INCREMENT BY 1 START WITH 1 MAXVALUE 999999999;

CREATE SEQUENCE seq_cht INCREMENT BY 1 START WITH 1 MAXVALUE 9999999999999999999;


insert into jado_user (userNum,id,password,name ,googleId)				
	values ('U'||to_char(lpad(seq_user.nextval, 9, '0')),'asdf','asdf','asdf','asdf');
insert into jado_user (userNum,id,password,name ,googleId)				
	values ('U'||to_char(lpad(seq_user.nextval, 9, '0')),'qwer','qwer','qwer','qwer');
insert into jado_user (userNum,id,password,name ,googleId)				
	values ('U'||to_char(lpad(seq_user.nextval, 9, '0')),'zxcv','zxcv','zxcv','zxcv');
insert into jado_user (userNum,id,password,name ,googleId)				
	values ('U'||to_char(lpad(seq_user.nextval, 9, '0')),'1234','1234','1234','1234');

insert into jado_project (proNum,title,userNum)
	values ('P'||to_char(lpad(seq_pro.nextval, 9, '0')),'������Ʈ1','U000000001');
insert into jado_project (proNum,title,userNum)
	values ('P'||to_char(lpad(seq_pro.nextval, 9, '0')),'������Ʈ2','U000000003');

insert into jado_member (userNum,proNum,memNum,agreed)
	values ('U000000001','P000000001', concat('U000000001','P000000001'),'Y');
insert into jado_member (userNum,proNum,memNum,agreed)
	values ('U000000002','P000000001', concat('U000000002','P000000001'),'Y');
insert into jado_member (userNum,proNum,memNum,agreed)
	values ('U000000003','P000000001', concat('U000000003','P000000001'),'Y');
insert into jado_member (userNum,proNum,memNum,agreed)
	values ('U000000003','P000000002', concat('U000000003','P000000002'),'Y');
insert into jado_member (userNum,proNum,memNum,agreed)
	values ('U000000004','P000000002', concat('U000000004','P000000002'),'Y');
	
insert into jado_theme (thmNum,proNum,themeName)
	values ('T'||to_char(lpad(seq_thm.nextval, 9, '0')),'P000000001','ä��1-1');
insert into jado_theme (thmNum,proNum,themeName)
	values ('T'||to_char(lpad(seq_thm.nextval, 9, '0')),'P000000001','ä��1-2');
insert into jado_theme (thmNum,proNum,themeName)
	values ('T'||to_char(lpad(seq_thm.nextval, 9, '0')),'P000000002','ä��2-1');
insert into jado_theme (thmNum,proNum,themeName)
	values ('T'||to_char(lpad(seq_thm.nextval, 9, '0')),'P000000002','ä��2-2');

	CREATE TABLE JADO_STORAGE
(
   FILENAME varchar2(200 char) NOT NULL,
   THMNUM varchar2(10 char) NOT NULL,
   realpath varchar2(400 char) NOT NULL
);