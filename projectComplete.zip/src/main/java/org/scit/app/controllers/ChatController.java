package org.scit.app.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.scit.app.persistence.ChatDao;
import org.scit.app.persistence.UserDao;
import org.scit.app.vo.Chat;
import org.scit.app.vo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

/**
 * Handles requests for the application home page.
 */
@Controller
public class ChatController {
	@Autowired
	SqlSession sqlSession;
	private static final Logger logger = LoggerFactory.getLogger(ChatController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String main() {
		return "index";
	}
	
	@RequestMapping(value = "zombie", method = RequestMethod.GET)
	public String zombieChat(Locale locale, Model model) {
		return "ZombieChat";
	}
	@RequestMapping(value = "sticky", method = RequestMethod.GET)
	public String sticky(Locale locale, Model model) {
		
		return "Sticky";
	}
	@RequestMapping(value = "cal", method = RequestMethod.GET)
	public String cal(Locale locale, Model model) {
		
		return "calendar";
	}
	@RequestMapping(value = "chatbox", method = RequestMethod.GET)
	public String chatbox(Locale locale, Model model,HttpSession session) {
		session.setAttribute("theme", "Design");
		return "chatbox";
	}
	@RequestMapping(value="doAjax", method = RequestMethod.POST)
	public @ResponseBody void doAjax(@RequestBody Map<String, Object> json){
		String content =  (String) json.get("data");
		Chat xx = new Chat();
		xx.setContent(content);
		ChatDao dao = sqlSession.getMapper(ChatDao.class);
		dao.insertRecord(xx);

	}
	@RequestMapping(value="record", method = RequestMethod.POST)
	public @ResponseBody void reCord(@RequestBody Map<String, Object> json, HttpSession session){
		String sender =  (String) json.get("sender");
		String content =  (String) json.get("content");
		System.out.println(session.toString());
	}
	@RequestMapping(value="fileupload", method = RequestMethod.POST)
	public @ResponseBody String fileUpload(MultipartHttpServletRequest request) throws IOException{
		String name = null;
		MultipartFile multiFile = null;
		Map<String, MultipartFile> xx = request.getFileMap();
		Set<String> keys = xx.keySet();
		for(String key:keys){
			multiFile= xx.get(key);
			name = multiFile.getOriginalFilename();
			String realPath = request.getServletContext().getRealPath("/upload");
			String fPath = realPath+"\\"+name ;
			FileOutputStream f = new FileOutputStream(new File(fPath));
			f.write(multiFile.getBytes());
		}
		return name;
	}
	@RequestMapping(value="download", method=RequestMethod.GET)
	public void download(HttpServletRequest request,String filename,HttpServletResponse response) throws UnsupportedEncodingException, IOException{
			//response header 수정
			String fname = new String(filename.getBytes("ISO8859-1"),"UTF-8");
			response.setHeader("Content-Disposition", "attachment;filename="+new String(fname.getBytes(),"ISO8859-1"));
			String fullPath = request.getServletContext().getRealPath("\\upload")+"\\"+fname;
			FileInputStream fin = new FileInputStream(fullPath );
			ServletOutputStream sout = response.getOutputStream();
			byte[] buffer = new byte[1024];
			
			int size=0;
			
			while((size = fin.read(buffer,0,buffer.length))!=-1){
				sout.write(buffer,0,size);
			}
			fin.close();sout.close();
	}
}
