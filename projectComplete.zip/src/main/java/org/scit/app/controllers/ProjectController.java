package org.scit.app.controllers;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.scit.app.persistence.ProjectDao;
import org.scit.app.vo.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProjectController {
	@Autowired
	SqlSession sqlSession;
	
	private static final Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="insertProject", method=RequestMethod.GET)
	public String insertProject(String title, String userNum, Project project, Model model) {
		System.out.println("들어왔는지는 알려줘야지잉");
		System.out.println(title);
		System.out.println(userNum);
		
		ProjectDao dao = sqlSession.getMapper(ProjectDao.class);
		int result = dao.insertProject(project);
		dao.insertLeader(userNum);
			
		return "redirect:afterLogin";
	}	
	
	
	@RequestMapping(value="gotoGroup", method=RequestMethod.POST)
	public String gotoGroup(String proNum, Model model) {
		System.out.println("들어왔는지는 알려줘야지잉");
		model.addAttribute("theme", "open");
		model.addAttribute("proNum", proNum);
		return "index";
	}
}
