package org.scit.app.controllers;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.scit.app.persistence.ChatDao;
import org.scit.app.persistence.ProjectDao;
import org.scit.app.persistence.UserDao;
import org.scit.app.vo.Chat;
import org.scit.app.vo.Gantchart;
import org.scit.app.vo.GantchartWarpper;
import org.scit.app.vo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired
	SqlSession sqlSession;
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String main() {
		return "index";
	}
	
	@RequestMapping(value = "chat", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		return "ChatRoom";
	}
	@RequestMapping(value = "zombie", method = RequestMethod.GET)
	public String zombie(Locale locale, Model model) {
		return "ZombieChat";
	}
	@RequestMapping(value = "sticky", method = RequestMethod.GET)
	public String sticky(Locale locale, Model model) {
		
		return "Sticky";
	}
	@RequestMapping(value = "cal", method = RequestMethod.GET)
	public String cal(Locale locale, Model model) {
		
		return "calendar";
	}
	@RequestMapping(value = "chatbox", method = RequestMethod.GET)
	public String chatbox(Locale locale, Model model) {
		
		return "chatbox";
	}
	@RequestMapping(value="doAjax", method = RequestMethod.POST)
	public @ResponseBody void doAjax(@RequestBody Map<String, Object> json){
		String content =  (String) json.get("data");
		System.out.println("inAjaxMEthod"+json);
		Chat xx = new Chat();
		xx.setContent(content);
		System.out.println(xx.toString());
		ChatDao dao = sqlSession.getMapper(ChatDao.class);
		dao.insertRecord(xx);

	}
	@RequestMapping(value="record", method = RequestMethod.POST)
	public @ResponseBody void reCord(@RequestBody Map<String, Object> json){
		String sender =  (String) json.get("sender");
		String content =  (String) json.get("content");
	}
	
	@RequestMapping(value="gantchartView",method=RequestMethod.GET)
	public String gantchartView(Model model, HttpSession session){
		ProjectDao dao=sqlSession.getMapper(ProjectDao.class);
		session.setAttribute("proNum", "P000000001");
		List<User> userList=dao.selectUserList((String)session.getAttribute("proNum"));
		model.addAttribute("userList", userList);
		return "gantchartView";			
	}
	
	@RequestMapping(value="insertGantchart",method=RequestMethod.POST)
	public String insertGantchart(GantchartWarpper warpper, HttpSession session){
		ProjectDao dao=sqlSession.getMapper(ProjectDao.class);
		dao.deleteGantchart((String)session.getAttribute("proNum"));
		for(int i=0;i<warpper.getList().size();i++){
			dao.insertGantchart(warpper.getList().get(i));
			for (int j=0;j<warpper.getList().get(i).getGantMemberList().size();j++){
				dao.insertGantMember(warpper.getList().get(i).getGantMemberList().get(j));
			}
		}		
		return "redirect:gantchartShowView";	
	}
	@RequestMapping(value="gantchartShowView",method=RequestMethod.GET)
	public String gantchart(HttpSession session, Model model){
		ProjectDao dao=sqlSession.getMapper(ProjectDao.class);
		List<Gantchart> list=dao.selectGantchart((String)session.getAttribute("proNum"));
		for (int i=0;i<list.size();i++){
			list.get(i).setGantMemberList(dao.selectGantMember(list.get(i).getGantNum()));
			System.out.println(list.get(i));
		}
		model.addAttribute("list", list);
		return "gantchartShow";			
	}
}
