package org.scit.app.persistence;

import org.scit.app.vo.Chat;

public interface ChatDao {
	public void insertRecord(Chat chat);
}
