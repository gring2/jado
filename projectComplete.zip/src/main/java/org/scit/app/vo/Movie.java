package org.scit.app.vo;

import org.springframework.web.multipart.MultipartFile;

public class Movie {
	private String	originalfile;
	private String	savedfile;
	private MultipartFile file;
	public String getOriginalfile() {
		return originalfile;
	}
	public void setOriginalfile(String originalfile) {
		this.originalfile = originalfile;
	}
	public String getSavedfile() {
		return savedfile;
	}
	public void setSavedfile(String savedfile) {
		this.savedfile = savedfile;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	@Override
	public String toString() {
		return "Movie [originalfile=" + originalfile + ", savedfile=" + savedfile + ", file=" + file + "]";
	}
}
