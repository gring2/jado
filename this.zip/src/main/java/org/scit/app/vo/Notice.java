package org.scit.app.vo;

public class Notice {
	private String id;
	private String content;
	private String proNum;
	private String noticeDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getProNum() {
		return proNum;
	}
	public void setProNum(String proNum) {
		this.proNum = proNum;
	}
	public String getNoticeDate() {
		return noticeDate;
	}
	public void setNoticeDate(String noticeDate) {
		this.noticeDate = noticeDate;
	}
	@Override
	public String toString() {
		return "Notice [id=" + id + ", content=" + content + ", proNum=" + proNum + ", noticeDate=" + noticeDate + "]";
	}
}
