package org.scit.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.connect.Connection;
import org.springframework.social.google.api.Google;
import org.springframework.social.google.api.impl.GoogleTemplate;
import org.springframework.social.google.api.plus.ActivitiesPage;
import org.springframework.social.google.api.plus.Person;
import org.springframework.social.google.api.plus.PlusOperations;
import org.springframework.social.google.connect.GoogleConnectionFactory;
import org.springframework.social.oauth2.AccessGrant;
import org.springframework.social.oauth2.GrantType;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@Autowired
	private GoogleConnectionFactory googleConnectionFactory;
	
	@Autowired
	private OAuth2Parameters googleOAuth2Parameters;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	private static final String CALLBACK_URI = "http://localhost:8888/app/googlelogin";
	
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String login(Model model){
		
		return "home";
	}
	
	@RequestMapping(value = "loginpage", method = RequestMethod.GET) //value값은 jsp에서 a태그로 보내는 값
	public String googlejoin() {
		OAuth2Operations oauthOperations = googleConnectionFactory.getOAuthOperations();
		String url = oauthOperations.buildAuthorizeUrl(GrantType.AUTHORIZATION_CODE, googleOAuth2Parameters);
		return "redirect:" + url;
	}
	
	@RequestMapping(value = "googlelogin", method = RequestMethod.GET)
	public String googlelogin(String code, Model model) {
			OAuth2Operations oauthOperations = googleConnectionFactory.getOAuthOperations();
			AccessGrant accessGrant = oauthOperations.exchangeForAccess(code, googleOAuth2Parameters.getRedirectUri(), null);
			String accessToken = accessGrant.getAccessToken();
			System.out.println("oauthOperations" + oauthOperations);
			System.out.println("accessGrant" +accessGrant);
			System.out.println("accessToken"+accessToken);
			Long expireTime =  accessGrant.getExpireTime();
			if (expireTime != null && expireTime < System.currentTimeMillis()) {
				accessToken = accessGrant.getRefreshToken();
				logger.info("accessToken is expired. refresh token = {}" , accessToken);
			}
					
			Connection<Google>connection = googleConnectionFactory.createConnection(accessGrant);
			Google google = connection == null ? new GoogleTemplate(accessToken) : connection.getApi();
			PlusOperations plusOperations = google.plusOperations();
			Person person = plusOperations.getGoogleProfile();
			
					
			model.addAttribute("googleId",person.getId());	//S태그로 받기위해서 보내는것
			model.addAttribute("googleName",person.getFamilyName());
			model.addAttribute("googleEmail",person.getAccountEmail());

			System.out.println(person.getId() + "//" + person.getFamilyName() + "//" + person.getAccountEmail() +"//" + person.getEmails() +"//" + person.getEmailAddresses());
			return "home";
	}
	
}
