package org.scit.app.socketServer;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.websocket.OnClose;

import javax.websocket.OnMessage;

import javax.websocket.OnOpen;

import javax.websocket.Session;

import javax.websocket.server.ServerEndpoint;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

@ServerEndpoint("/echo")

public class SocketServer {

static Set<Session> sessionUsers = Collections.synchronizedSet(new HashSet<Session>());
private String nickname;
// 클라이언트가 새로 접속할 때마다 한개의 Session 객체가 생성된다.
// Session 객체를 컬렉션에 보관하여 두고 해당 클라이언트에게 데이터를 전송할 때마다 사용한다
private Session session;
private static final HashMap<String, Session> sessionMap = new HashMap();
	

/**

 * When the client try to connection to websocket server,

 * open session and add information to the collection.

 *

 * @author GOEDOKID

 * @since 2015. 3. 18. 

 * @param Session userSession

 * @return

 */

@OnOpen

public void handleOpen(Session userSession) {
	sessionUsers.add(userSession);
    this.session = userSession;
    String[] params = session.getQueryString().split("&");
    String usr = params[0].split("=")[1];
	try{
		usr = URLDecoder.decode(usr,"UTF-8");//파라미터로 전달된 데이터는 URLDecoder를 사용하여 복원한다
	}catch(Exception e){
	}
	this.nickname=usr;
	System.out.println(usr);
	sessionMap .put(this.nickname, session);
	System.out.println(sessionMap.get(this.nickname));
}



/**

 * Send to message designated client by "websocket.send()" command.

 *

 * @author GOEDOKID

 * @since 2015. 3. 18. 

 * @param String message

 * @return

 */

@OnMessage

public void handleMessage(Session session, String message) throws IOException {
	System.out.println("DDDSDS");
	System.out.println(message);
	JSONObject jobj = (JSONObject)JSONValue.parse(message);
	String usrName = (String)jobj.get("usrName");
	String way = (String)jobj.get("way");
	String content = (String)jobj.get("content");
	System.out.println(way);
		Iterator<Session> iterator = sessionUsers.iterator();
		while(iterator.hasNext()) {

			iterator.next().getBasicRemote().

                   sendText(JSONConverter(message, usrName));

		}	
		
		sendToOne(usrName, sessionMap.get(this.nickname+"zombie"));

}

private void sendToOne(String msg, Session ses) {
  	try {
  		String[] params = session.getQueryString().split("&");
    	System.out.println(msg);
  		String usr = params[0].split("=")[1];
    	try{
    		usr = URLDecoder.decode(usr,"UTF-8");//파라미터로 전달된 데이터는 URLDecoder를 사용하여 복원한다
    	}catch(Exception e){
    		
    	}
  		JSONObject jsonObject = new JSONObject();
  		jsonObject.put("message", msg);
  		ses.getBasicRemote().sendText(jsonObject.toString());}
	 catch (IOException e) {
		e.printStackTrace();
	}
  }

/**

 * Session remove When browser down or close by client control

 * 

 * @author GOEDOKID

 * @since 2015. 3. 18. 

 * @param 

 * @return

 */

@OnClose

public void handleClose(Session session) {

	 String[] params = session.getQueryString().split("&");
     String usr = params[0].split("=")[1];
 	try{
 		usr = URLDecoder.decode(usr,"UTF-8");//파라미터로 전달된 데이터는 URLDecoder를 사용하여 복원한다
 	}catch(Exception e){
 	}
 	this.nickname=usr;
 	System.out.println(usr);
 	sessionMap .put(this.nickname, session);
 	System.out.println(sessionMap.get(this.nickname));

	sessionUsers.remove(session);

}

	

public String JSONConverter(String message,  String type) {

	JSONObject jsonObject = new JSONObject();

	jsonObject.put("type", type);

	jsonObject.put("message", message);

	return jsonObject.toString();

}

}

