/*package org.scit.app.socketServer;
import java.util.HashMap;
import java.util.Iterator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.PongMessage;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

@ServerEndpoint("/echo")
public class MyWebSocket {
	  private static final String GUEST_PREFIX = "Guest";
	    // AtomicInteger 클래스는 getAndIncrement()를 호출할 때마다 카운터를 1씩 증가하는 기능을 가지고 있다
	    private static final AtomicInteger connectionIds = new AtomicInteger(0);
	    // CopyOnWriteArraySet 을 사용하면 컬렉션에 저장된 객체를 좀더 간편하게 추출할 수 있다
	    // 예를 들어, toArray()메소드를 통해 쉽게 Object[] 형의 데이터를 추출할 수 있다.
	    private static final Set<MyWebSocket> connections =
	            new CopyOnWriteArraySet<MyWebSocket>();

	    private String nickname;
	    // 클라이언트가 새로 접속할 때마다 한개의 Session 객체가 생성된다.
	    // Session 객체를 컬렉션에 보관하여 두고 해당 클라이언트에게 데이터를 전송할 때마다 사용한다
	    private Session session;
		private static final HashMap<String, Session> sessionMap = new HashMap();
	public MyWebSocket() {
		String sss = "111";
		
		// 클라이언트가 접속할 때마다 서버측에서는 Thread 가 새로 생성되는 것을 확인할 수 있다
  	String threadName = "Thread-Name:"+Thread.currentThread().getName();
  	// getAndIncrement()은 카운트를 1 증가하고 증가된 숫자를 리턴한다
      nickname = GUEST_PREFIX + connectionIds.getAndIncrement();
      System.out.println(threadName+", "+nickname);
	}
	@OnOpen
	
	public void echoOpen(Session session) {
	     this.session = session;
	        connections.add(this);
	        String[] params = session.getQueryString().split("&");
	        String usr = params[0].split("=")[1];
	    	try{
	    		usr = URLDecoder.decode(usr,"UTF-8");//파라미터로 전달된 데이터는 URLDecoder를 사용하여 복원한다
	    	}catch(Exception e){
	    	}
	    	this.nickname=usr;
	    	System.out.println(usr);
	    	sessionMap .put(this.nickname, session);
	    	System.out.println(sessionMap.get(this.nickname));
	}

   //텍스트 데이터를 수신할 때 호출됨(session을 이용하여 파라미터를 추출할 수 있고 일반 데이터는 msg에 전달된다)
  @OnMessage
  public void echoTextMessage(Session session, String msg, boolean last) {

      // 클라이언트가 요청할 때 전달한 파라미터(usr=홍길동)는 아래처럼 추출할 수 있다
      String[] params = session.getQueryString().split("&");
  	String usr = params[0].split("=")[1];
  	try{
  		usr = URLDecoder.decode(usr,"EUC-KR");//파라미터로 전달된 데이터는 URLDecoder를 사용하여 복원한다
  	}catch(Exception e){
  		
  	}

      // JSON-Simple 라이브러리를 사용하여 JSON 문자열을 처리한다
  	JSONObject jobj = (JSONObject)JSONValue.parse(msg);
  	System.out.println("OnMESSAGE");
  	System.out.println(jobj.toString());
  	String usrName = (String)jobj.get("usrName");
  	String phone = (String)jobj.get("phone");
  	String content = (String)jobj.get("content");
		System.out.println(usrName);
		String x = this.nickname+"zombie";
		System.out.println(x);
      	sendToOne(usrName, sessionMap.get(x));
  }
  private void sendToOne(String msg, Session ses) {
  	try {
  		System.out.println("sessionis");
  		System.out.println(ses);
  	ses.getBasicRemote().sendText(msg);
	} catch (IOException e) {
		e.printStackTrace();
	}
  }
   // 바이너리 데이터를 수신할 때 호출됨
  @OnMessage
  public void echoBinaryMessage(Session session, ByteBuffer bb,
          boolean last) {
      try {
          if (session.isOpen()) {
              //session.getBasicRemote().sendBinary(bb, last);
          	session.getBasicRemote().sendText("파일이 서버에 도착했어요~", last);
              File file = new File("D:/test/sample.txt");

          	// Set to true if the bytes should be appended to the file;
          	// set to false if the bytes should replace current bytes
          	// (if the file exists)
          	boolean append = false;

          	try {
          	    // Create a writable file channel
          	    FileChannel wChannel = new FileOutputStream(file, append).getChannel();

          	    // Write the ByteBuffer contents; the bytes between the ByteBuffer's
          	    // position and the limit is written to the file
          	    wChannel.write(bb);

          	    // Close the file
          	    wChannel.close();
          	} catch (IOException e) {
          	}
          }
      } catch (IOException e) {
          try {
              session.close();
          } catch (IOException e1) {
              // Ignore
          }
      }
  }

  *//**
   * Process a received pong. This is a NO-OP.
   *
   * @param pm    Ignored.
   *//*
  @OnMessage
  public void echoPongMessage(PongMessage pm) {
      // NO-OP
  }
  
  @OnClose
  public void onClose() {
      // disconnection handling
  }
  
  @OnError
  public void onError(Session session, Throwable throwable) {
      // Error handling
  }
}*/